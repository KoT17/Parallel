#include <string>
#include <iostream>

using namespace std;

#include "chopstick.h"

Chopstick::Chopstick() {

}
